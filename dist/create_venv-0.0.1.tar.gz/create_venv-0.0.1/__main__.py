from create_venv import create_venv

if __name__ == "__main__":
    create_venv()
