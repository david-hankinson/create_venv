# create_env - A simple interactive tool to create python virtual environments

## Usage

### From source: 

`pip install -e .`
`python3 create_venv`